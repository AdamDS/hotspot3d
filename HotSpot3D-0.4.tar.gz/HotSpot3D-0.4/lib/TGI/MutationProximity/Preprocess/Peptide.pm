package TGI::MutationProximity::Physical::Peptide;
#
#----------------------------------
# $Authors: Beifang Niu & Adam D Scott $
# $Date: 2014-01-14 14:34:50 -0500 (Tue Jan 14 14:34:50 CST 2014) $
# $Revision:  $
# $URL: $
# $Doc: $ peptide class 
#----------------------------------
#
use strict;
use Carp;
use Scalar::Util qw( reftype );
use TGI::MutationProximity::Physical::AminoAcid;
# Ordered amino acids
sub new {    
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    $self->{CHAIN} = shift; # Chain id from PDB file
    $self->{PROTEIN} = shift; # Gene from PDB file
    $self->{AMINOACIDS} = {}; # Hash of AminoAcid objects
                      # key = residue number
                      # value = ref to AminoAcid object
    bless ($self, $class);
    return $self;
}

sub chain {
    # Chain name (single letter)
    my $self = shift;
    if (@_) { $self->{CHAIN} = shift; }
    return $self->{CHAIN};
}

sub protein {
    # Chain name (single letter)
    my $self = shift;
    if (@_) { $self->{CHAIN} = shift; }
    return $self->{CHAIN};
}

sub removeAmbiguousAminoAcids {
    # If any of the amino acid positions in this peptide have more than 
    # one amino acid name associated with them
    # they were marked as ambiguous e.g. position 12 is ambiguous
    #    ATOM      1  N  APRO A   12       3.278  21.202  20.087  0.83 56.23           N  
    #    ATOM      8  N  BSER A   12       3.302  21.148  20.087  0.17 56.57           N 
    my $self = shift;
    foreach my $aminoAcid ( @{$self->getAminoAcids()} ) {
		$self->removeAminoAcid( $aminoAcid );
    }

}  

sub addAminoAcid {
    # Input: amino acid residue number, 
    # ref to AminoAcid object
    my ( $self , $aminoAcid ) = @_;
    $self->{AMINOACIDS}->{$aminoAcid->position()} = $aminoAcid;
}

sub removeAminoAcid {
	my ( $self , $aminoAcid ) = @_;
	if ( reftype( $aminoAcid ) == "SCALAR" ) { # $aminoAcid is a position
		if ( $self->{AMINOACIDS}->{$aminoAcid} ) {
			delete $self->{AMINOACIDS}->{$aminoAcid};
		}
	} else { # $aminoAcid is a reference to an AminoAcid
		if ( $self->{AMINOACIDS}->{$aminoAcid->position()} ) {
			delete $self->{AMINOACIDS}->{$aminoAcid->position()};
		}
	}
}

sub getAminoAcid {
    # Input: position number
    # Return: ref to AminoAcid object at that position
    my ( $self , $position ) = @_;
	my $aminoAcids = $self->getAminoAcids();
	foreach my $aminoAcid ( @{$aminoAcids} ) {
		if ( $aminoAcid->position() == $position ) {
			return $self->{AMINOACIDS}->{$position};
		}
	}
	return undef;
}

sub getAminoAcids {
    # Return: ref to hash with key = residue number, 
    # value = ref to AminoAcid object
    my $self = shift;
	my @aminoAcids = values %{$self->{AMINOACIDS}};
	return \@aminoAcids;
}

sub getPositions {
	my ( $self ) = @_;
	my $positions = ();
	foreach my $aminoAcid ( @{$self->getAminoAcids()} ) {
		push @{$positions} , $aminoAcid->position();
	}
	@{$positions} = sort {$a<=>$b} @{$positions};
	return $positions;
}

sub getSequence {
	my $self = shift;
	my $sequence = ();
	my $aminoAcid = new AminoAcid();
	foreach my $position ( $self->getPositions() ) {
		$aminoAcid = $self->getAminoAcid( $position );
		push @{$sequence} , $aminoAcid->name();
	}
	return $sequence;
}

return 1;
