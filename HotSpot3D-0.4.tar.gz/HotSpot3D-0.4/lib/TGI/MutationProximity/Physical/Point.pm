package TGI::MutationProximity::Physical::Point;
#
#----------------------------------
# $Authors: Beifang Niu & Adam D Scott $
# $Date: 2014-01-14 14:34:50 -0500 (Tue Jan 14 14:34:50 CST 2014) $
# $Revision:  $
# $URL: $
# $Doc: $ do prioritization 
#----------------------------------
#
use strict;
use Carp;
use Scalar::Util qw( reftype );
# Point with X, Y, Z coordinates
# Used to calculate distance between atoms in PDB structure
sub new {    
    my ( $proto ) = shift;
    my $class = ref($proto) || $proto; 
    my $self = {};
	$self->{XYZ} = ();
	#print "new\n";
	while ( @_ ) {
		my $r = shift;
		#print $r."\n";
		push @{$self->{XYZ}} , $r;  # array of values in order x,y,z
	}
    bless ($self, $class);
    return $self;
}

sub print {
	my $self = shift;
	print "XYZ = ";
	print join( ", " , $self->xyz() )."\n";
}

sub xyz {
    # Get/Set array that holds X,Y,Z values
    # Returns an array
    my $self = shift;
	#print "xyz\n";
    if ( @_ ) { 
		$self->{XYZ} = ();
		while ( @_ ) {
			my $coord = shift;
            #print $coord."\n";
			$coord = $self->round( $coord );
			push @{$self->{XYZ}}, $coord;
		}
    }
	#print join( ", " , @{$self->{XYZ}} )."\n";
    return @{$self->{XYZ}};
}

sub translate {
	# Adds two points together
	# Returns the sum
	my ( $self , $other ) = @_;
	#print "add\n";
	my ( $x1 , $y1 , $z1 ) = $self->xyz();
	my ( $x2 , $y2 , $z2 ) = $other->xyz();
	$self->{XYZ} = ();
	push @{$self->{XYZ}} , $x1+$x2;
	push @{$self->{XYZ}} , $y1+$y2;
	push @{$self->{XYZ}} , $z1+$z2;
	return @{$self->{XYZ}};
}

sub add {
	# Adds two points together
	# Returns the sum
	my ( $self , $other ) = @_;
	#print "add\n";
	my ( $x1 , $y1 , $z1 ) = $self->xyz();
	my ( $x2 , $y2 , $z2 ) = $other->xyz();
	return ( $x1+$x2 , $y1+$y2 , $z1+$z2 );
}

sub difference {
	# Adds two points together
	# Returns the sum
	my ( $self , $other ) = @_;
	#print "difference\n";
	my ( $x1 , $y1 , $z1 ) = $self->xyz();
	my ( $x2 , $y2 , $z2 ) = $other->xyz();
	return ( $x1-$x2 , $y1-$y2 , $z1-$z2 );
}

sub scalarDivision {
	my ( $self , $denominator ) = @_;
	#print "scalarDivision\n";
	my ( $x1 , $y1 , $z1 ) = $self->xyz();
	return ( $x1/$denominator , $y1/$denominator , $z1/$denominator );
}

sub distance {
	my ( $self , $other ) = @_;
	#print "distance\n";
	my ( $dx , $dy , $dz ) = $self->difference( $other );
	return ( sqrt( $dx*$dx + $dx*$dx + $dx*$dx ) );
}

sub innerProduct {
	my ( $self , $other ) = @_;
	#print "innerProduct\n";
	my ( $x1 , $y1 , $z1 ) = $self->xyz();
	my ( $x2 , $y2 , $z2 ) = $other->xyz();
	return ( $x1*$x2 + $y1*$y2 + $z1*$z2 ); 
}

sub sameAs {
    # Input: ref to a Point object
    # Return: 1 if the point has same coordinates as this one, 0 if not
    # This was changed from == comparison to 'eq' since seemingly equivalent
    # numbers were not comparing as expected.  Does Perl store as a float?
    my ( $self , $other ) = @_;
	#print "sameAs\n";
    my ($aX, $aY, $aZ) = $self->xyz();
    my ($bX, $bY, $bZ) = $other->xyz();
    return ( $aX eq $bX && $aY eq $bY && $aZ eq $bZ );
}

sub round {    
    # Round off number to nearest 0.001
    my $self = shift;
    my $num = shift;
	if ( $num >= 0 ) {
		$num += 0.0005;
	} else {
		$num -= 0.0005;
	}
    if ( $num =~ /(-?\d+\.\d{3})/ ) { $num = $1; } 
    return $num;
}

return 1;  
