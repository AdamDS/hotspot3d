package TGI::MutationProximity::Physical::Structure;
#
#----------------------------------
# $Authors: Adam D Scott 
# $Date: 2015*10*29 $
# $Revision:  $
# $URL: $
# $Doc: $ crystal structure class 
#----------------------------------
#
use strict;
use warnings;

use Carp;
use LWP::Simple;

use TGI::MutationProximity::Physical::AminoAcid;
use TGI::MutationProximity::Physical::Heterogen;
use TGI::MutationProximity::Physical::Peptide;

sub new {
    my ( $class ) = @_;    
	my $self = {};
	$self->{PEPTIDES} = {};
    bless ( $self , $class );
	return $self;
}

sub print {
	my $self = shift;
	print "PEPTIDES => {\n";
	my $chains = $self->getPeptideChains();
	foreach my $chain ( @{$self->getPeptideChains()} ) {
		$peptide = $self->getPeptide( $chain );
		$peptide->print();
	}
	print "} #end PEPTIDES\n";
}

sub addPeptide {
	my ( $self , $peptide ) = shift;
	if ( not exists $self->{PEPTIDES}->{$peptide->chain()} ) {
		$self->{PEPTIDES}->{$peptide->chain()} = $peptide;
	}
}

sub addAminoAcid {
	my ( $self , $aminoAcid , $chain ) = shift;
	my $peptide = new Peptide();
	if ( defined $self->getPeptide( $chain ) ) {
		$peptide = $self->getPeptide( $chain );
	} else {
		$peptide->chain( $chain );
	}
	$peptide->addAminoAcid( $aminoAcid );
	$self->{PEPTIDES}->{$chain} = $peptide;
}

sub getPeptides {
	my ( $self ) = @_;
	my $peptides = ();
	foreach $chain ( sort{ $a <=> $b} keys %{$self->{PEPTIDES}} ) {
		push @{$peptides} , $self->{PEPTIDES}->{$chain};
	}
	return $peptides;
}

sub getPeptideChains {
	my ( $self ) = @_;
	my $chains = ();
	my $peptide = new Peptide();
	foreach my $peptide ( $self->getPeptides() ) {
		push @{$chains} , $peptide->chain();
	}
	return $chains;
}

sub getPeptide {
	my ( $self , $chain ) = @_;
	if ( exists $self->{PEPTIDES}->{$chain} ) {
		return $self->{PEPTIDES}->{$chain};
	}
	return undef;
}

return 1;
