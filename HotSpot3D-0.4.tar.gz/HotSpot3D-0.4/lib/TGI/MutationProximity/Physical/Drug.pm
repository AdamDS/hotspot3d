package TGI::MutationProximity::Physical::Drug;
#
#----------------------------------
# $Authors: Adam D Scott $
# $Date: 2015*10*29 $
# $Revision:  $
# $URL: $
# $Doc: $ drug class
#----------------------------------
#
use strict;
use warnings;

use Carp;
use TGI::MutationProximity::Physical::Compound;
use TGI::MutationProximity::Physical::Heterogen;
our @ISA = qw( Heterogen );
# Protein compounds in crystal structure
sub new {    
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = $class->SUPER::new( shift , shift );
    $self->{NAME} = shift; # drug name in PDB
    $self->{ALIASES} = (); # drug name in PDB
    bless ($self, $class);
    return $self;
}

sub name {
	my $self = shift;
	if ( @_ ) {
		$self->{NAME} = shift;
	}
	return $self->{NAME};
}

sub sameAs {
	my ( $self , $other ) = @_;
	if ( $self->name() eq $self->name() ) {
		$self->sameAs( $other );
	}
	return 1;
}

return 1;
