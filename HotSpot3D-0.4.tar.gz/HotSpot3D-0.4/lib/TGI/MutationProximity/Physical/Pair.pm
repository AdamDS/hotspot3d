package TGI::Mutpro::Preprocess::Pair;
#
#----------------------------------
# $Authors: Adam D Scott 
# $Date: 2015*10*28 $
# $Revision:  $
# $URL: $
# $Doc: $ do prioritization 
#----------------------------------
#
use strict;
use Carp;
use TGI::Mutpro::Preprocess::Point;
use TGI::Mutpro::Preprocess::Compound;
# Point with X, Y, Z coordinates
# Used to calculate distance between atoms in PDB structure
sub new {    
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
	$self->{COMPOUND1} = new Compound();
	$self->{COMPOUND2} = new Compound();
    $self->{DISTANCE} = undef;  # distance between points
    $self->{CUSTOMDISTANCE} = undef;  # distance between points
    $self->{CHAINPVALUE} = undef; # statistical significance of proximity in chain
    $self->{STRUCTUREPVALUE} = undef; # statistical significance of proximity in structure
	# Values rounded to nearest thousandth
    bless ($self, $class);
    return $self;
}

sub distance {
    # Input: ref to AminoAcid object
    # Return: shortest distance between any
    #         two points in this amino acid
    #         and the input amino acid
    my $self = shift;
	if ( @_ || undef $self->{DISTANCE} ) {
		my $minDistance = $distance = 1e10; # 1m
		my $atom1 = new Atom();
		my $atom2 = new Atom();
		foreach $atom1 ( @{$self->{COMPOUND1}->getAtoms()} ) {
			foreach $atom2 ( @{$self->{COMPOUND2}->getAtoms()} ) {
				$distance = $atom1->distance( $atom2 );
				if ( $distance < $minDistance ) {
					$minDistance = $distance;
				}
			}
		}
		($minDistance < 1e10) || confess "Did not get any distance values";
		$self->{DISTANCE} = $self->round( $minDistance );
		$self->{CUSTOMDISTANCE} = $self->{DISTANCE};
	}
	return $self->{DISTANCE};
}

sub specificDistance {
    # Input: ref to a Point object
    # Return: distance between this point and input point rounded to nearest thousandths
    my ( $self , $nameOf1 , $nameOf2 ) = @_;
	my $point1 = new Point();
	$point1 = $self->{COMPOUND1}->xyzOf( $nameOf1 );
	if ( undef $point1 ) {
		return;
	}
	my $point2 = new Point();
	$point2 = $self->{COMPOUND2}->xyzOf( $nameOf2 );
	if ( undef $point2 ) {
		return;
	}
	my $distance = $point1->distance( $point2 );
    $self->{CUSTOMDISTANCE} = $self->round($distance);
}

sub centersDistance {
	my $self = shift;
	$self->specificDistance( "CENTER" , "CENTER" );
	return $self->{CUSTOMDISTANCE};
}

sub alphasDistance {
	my $self = shift;
	$self->specificDistance( "CA" , "CA" );
	return $self->{CUSTOMDISTANCE};
}

sub sameAs {
    # Input: ref to a Point object
    # Return: 1 if the point has same coordinates as this one, 0 if not
    # This was changed from == comparison to 'eq' since seemingly equivalent
    # numbers were not comparing as expected.  Does Perl store as a float?
    my ( $self , $other ) = shift;
	if ( (  $self->{COMPOUND1}->sameAs( $other->{COMPOUND1} ) || 
			$self->{COMPOUND2}->sameAs( $other->{COMPOUND1} )
		 ) &&
		 (	$self->{COMPOUND1}->sameAs( $other->{COMPOUND2} ) || 
			$self->{COMPOUND2}->sameAs( $other->{COMPOUND2} )
		 ) {
		return 1;
	}
	return 0;
}
 
return 1;  
