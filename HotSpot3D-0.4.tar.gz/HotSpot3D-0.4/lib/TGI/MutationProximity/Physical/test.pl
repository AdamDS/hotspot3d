#!/usr/bin/perl

use strict;
use warnings;

use Point;
use Atom;
use Compound;
use AminoAcid;
use Peptide;
use Structure;
use PdbStructure;
use Scalar::Util qw( reftype );

if ( 1 ) {
	my $pdb = new PdbStructure( '3HIZ' );
	my $page = $pdb->page();
	$pdb->print();
}
my $point0 = new Point();
$point0->xyz( -1 , -1 , 1 );
my $point1 = new Point( 1 , -1 , 1 );
print join( ", " , $point0->add( $point1 ) )."\n";
print join( ", " , $point1->scalarDivision( 2 ) )."\n";
print join( ", " , $point0->difference( $point1 ) )."\n";
print $point0->distance( $point1 )."\n";
print $point0->innerProduct( $point1 )."\n";
print join( ", " , $point0->translate( $point1 ) )."\n";
