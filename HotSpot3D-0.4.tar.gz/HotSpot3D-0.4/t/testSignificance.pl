#!/usr/bin/perl

use strict;
use warnings;

use TGI::Mutpro::Main::Significance;
use FileHandle;
use IO::File;
use Getopt::Long;

#my $object= new Significance();
my $object = new Significance( "~ascott/Projects/HotSpot3D/Comparison/ClusterLikeSpacePAC/chosen.cancer.heteromer.hup",
"~/Projects/HotSpot3D/Comparison/ClusterLikeSpacePAC/Heteromer/NewPValuePairwise/chosen.cancer.heteromer",
"~/Projects/HotSpot3D/Comparison/ClusterLikeSpacePAC/single_molecule_pvalue.pairwise",
"~/Projects/HotSpot3D/Comparison/ClusterLikeSpacePAC/Heteromer/NewPValueClusters/chosen.cancer.heteromer",
"~/Projects/HotSpot3D/Comparison/ClusterLikeSpacePAC/single_molecule_pvalue.intra.20..05.10.clusters",
"~/To_gc2706/dinglab/medseq/AA_Conversion/AAabbrv",
"~/To_gc2706/dinglab/medseq/Preprocessing_Output_20141023/proximityFiles/cosmicanno/",
1000000);

$object->process();
print $object->getDistances();
print "Hello";
